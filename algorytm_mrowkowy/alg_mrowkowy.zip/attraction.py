class Attraction:
    def __init__(self, index: int, x: int, y: int):
        self.index = index - 1
        self.x = x
        self.y = y
