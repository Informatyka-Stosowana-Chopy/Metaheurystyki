from simulation import Simulation

s = Simulation()
s.main()
